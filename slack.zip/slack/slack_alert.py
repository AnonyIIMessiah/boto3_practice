import requests
import json
slack_web_hook = 'https://hooks.slack.com/services/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'

def send_slack(event, context):
    print(str(event))
    slack_message = {'text': 'EC2 Instance Stopped'}
    resp = requests.post(slack_web_hook,data=json.dumps(slack_message))
    return resp.text 